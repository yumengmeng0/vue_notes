module.exports = {
  devServer: {
    open: true,
    port: 8088,
  },
};
