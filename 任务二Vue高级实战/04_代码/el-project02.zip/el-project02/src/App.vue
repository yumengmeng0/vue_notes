<template>
  <div id="app">
    <!-- 根据访问路径,渲染路径匹配到的组件 -->
    <router-view></router-view>
  </div>
</template>

<style></style>
