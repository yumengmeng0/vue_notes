import Vue from "vue";
import VueRouter from "vue-router";

//导入Login.vue组件
import Login from "@/components/Login";

//导入布局组件
import Index from "@/components/Index";

//导入课程组件
import Course from "@/components/Course";

Vue.use(VueRouter);

const routes = [
  //访问 / .也调转到 login
  {
    path: "/",
    //redirect: "login", //重定向到login
    redirect: "index",
  },
  //登录路由
  {
    path: "/login",
    name: "login",
    component: Login,
  },
  //布局路由
  {
    path: "/index",
    name: "index",
    component: Index,
    //添加子路由,使用 children属性 来表示子路由
    children: [
      //课程信息子路由
      {
        path: "/course",
        name: "course",
        component: Course,
      },
    ],
  },
];

// 解决ElementUI导航栏中的vue-router在3.0版本以上重复点菜单报错问题
const originalPush = VueRouter.prototype.push;
VueRouter.prototype.push = function push(location) {
  return originalPush.call(this, location).catch((err) => err);
};

const router = new VueRouter({
  routes,
});

export default router;
